package softuni.gamestore.gameBindingModel;

public class GameBindingModel {
    //TODO
}
