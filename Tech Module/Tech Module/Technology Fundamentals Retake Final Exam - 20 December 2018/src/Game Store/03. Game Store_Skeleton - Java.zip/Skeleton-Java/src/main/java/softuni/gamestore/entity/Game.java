package softuni.gamestore.entity;

import javax.persistence.*;

@Entity
@Table(name = "games")
public class Game {
   //TODO
}
