package meisterTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeistertaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeistertaskApplication.class, args);
	}
}
