package com.softunispring.springintro.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
