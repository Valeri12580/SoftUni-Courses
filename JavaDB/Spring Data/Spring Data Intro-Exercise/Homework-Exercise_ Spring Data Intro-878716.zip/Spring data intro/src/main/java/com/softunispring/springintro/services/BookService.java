package com.softunispring.springintro.services;

import com.softunispring.springintro.entities.Book;

import java.io.IOException;
import java.util.List;

public interface BookService {

    void seedBooks() throws IOException;

    List<Book> getAllBooksAfter2000();
    void printAllAuthorsWithOneBookBefore1990();
    List<Book> getAllBooksByAuthorOrderedByReleaseDate(String firstName, String lastName);
}
