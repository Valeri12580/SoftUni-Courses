package com.softunispring.springintro.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
