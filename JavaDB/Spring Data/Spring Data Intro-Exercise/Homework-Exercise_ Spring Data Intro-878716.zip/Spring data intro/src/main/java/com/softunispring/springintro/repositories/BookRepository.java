package com.softunispring.springintro.repositories;

import com.softunispring.springintro.entities.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    boolean existsByTitle(String title);
    List<Book> getAllByReleaseDateAfter(LocalDate localDate);
    List<Book> getAllByReleaseDateBefore(LocalDate localDate);

    List<Book> getAllByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescTitleAsc(String firstName, String lastName);

}
