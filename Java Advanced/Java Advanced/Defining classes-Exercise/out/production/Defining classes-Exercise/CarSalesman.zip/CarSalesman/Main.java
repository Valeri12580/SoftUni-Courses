package CarSalesman;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        Map<String,Engine> dataForEngines=new LinkedHashMap<>();

        int n= Integer.parseInt(reader.readLine());
        for (int i = 0; i <n ; i++) {
            String[]inputEngine=reader.readLine().split(" ");
            String model=inputEngine[0];
            int power=Integer.parseInt(inputEngine[1]);
            Engine engine=new Engine(model,power);


            if(inputEngine.length==4){
                engine.setDisplacement(inputEngine[2]);
                engine.setEfficiency(inputEngine[3]);
            }else {
                if(inputEngine.length==3 &&Character.isDigit(inputEngine[2].charAt(0)) ){
                    engine.setDisplacement(inputEngine[2]);

                }else if(inputEngine.length==3){
                    engine.setEfficiency(inputEngine[2]);
                }
            }

            dataForEngines.put(model,engine);


        }
        int m=Integer.parseInt(reader.readLine());
        Map<String,Car>finalData=new LinkedHashMap<>();

        for (int i = 0; i <m; i++) {
            String[] inputCar=reader.readLine().split(" ");
            String model=inputCar[0];
            String engine=inputCar[1];



            Car car =new Car(model,dataForEngines.get(engine));
            if(inputCar.length==4){
                car.setWeight(inputCar[2]);
                car.setColor(inputCar[3]);

            }else {
                if(inputCar.length==3 &&Character.isDigit(inputCar[2].charAt(0)) ){
                    car.setWeight(inputCar[2]);

                }else if(inputCar.length==3){
                    car.setColor(inputCar[2]);
                }
            }

            finalData.put(model,car);

        }

        for (Map.Entry<String, Car> stringCarEntry : finalData.entrySet()) {
            System.out.println(stringCarEntry.getKey()+":");
            System.out.println(stringCarEntry.getValue().getEngine().getModel()+":");
            System.out.println("Power: "+stringCarEntry.getValue().getEngine().getPower());
            System.out.println("Displacement: "+stringCarEntry.getValue().getEngine().getDisplacement());
            System.out.println("Efficiency: "+stringCarEntry.getValue().getEngine().getEfficiency());
            System.out.println("Weight: "+stringCarEntry.getValue().getWeight());
            System.out.println("Color: "+stringCarEntry.getValue().getColor());

        }



    }
}
