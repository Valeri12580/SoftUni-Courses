package HotelReservation;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        String[] input=scanner.nextLine().split(" ");
        double pricePerDay=Double.parseDouble(input[0]);
        int numberOfDays=Integer.parseInt(input[1]);
        String season=input[2].toUpperCase();
        String discount =input[3].toUpperCase();

       int getDiscount=DiscountType.valueOf(discount).getValue();

       int multiplier=Season.valueOf(season).getValue();
       printTotalSum(pricePerDay,numberOfDays,getDiscount,multiplier);


    }

    public static void printTotalSum(double pricePerDay,int numberOfDays,int getDiscount,int multiplier){
        double pricesWithoutDiscounts=pricePerDay*numberOfDays*multiplier;
        double finalSum=pricesWithoutDiscounts-(pricesWithoutDiscounts*getDiscount/100);

        System.out.printf("%.2f",finalSum);
    }
}
