package restaurant;

public class Soup extends Starter {
    public Soup(String name, double price, double grams) {
        super(name, price, grams);
    }
}
