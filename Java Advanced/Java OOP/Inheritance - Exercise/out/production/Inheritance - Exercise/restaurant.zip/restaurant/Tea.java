package restaurant;

public class Tea extends HotBeverage {
    public Tea(String name, double price, double milliliters) {
        super(name, price, milliliters);
    }
}
