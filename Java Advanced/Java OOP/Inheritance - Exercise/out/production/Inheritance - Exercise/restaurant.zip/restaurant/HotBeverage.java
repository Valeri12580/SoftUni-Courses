package restaurant;

public class HotBeverage extends Beverage {

    public HotBeverage(String name, double price, double milliliters) {
        super(name, price, milliliters);
    }
}
