package restaurant;

public class Starter extends Food {
    public Starter(String name, double price, double grams) {
        super(name, price, grams);
    }
}
