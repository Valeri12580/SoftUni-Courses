package restaurant;

public class MainDish extends Food{

    public MainDish(String name, double price, double grams) {
        super(name, price, grams);
    }
}
