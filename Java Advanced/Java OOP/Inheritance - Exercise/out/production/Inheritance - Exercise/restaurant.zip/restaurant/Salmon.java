package restaurant;

public class Salmon extends MainDish {
    protected  final double SALMON_GRAMS = 22;

    public Salmon(String name, double price, double grams) {
        super(name, price, grams);
    }
}
