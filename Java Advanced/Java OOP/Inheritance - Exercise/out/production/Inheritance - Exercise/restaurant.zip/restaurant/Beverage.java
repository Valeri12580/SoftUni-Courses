package restaurant;

public class Beverage extends Product {
    protected double milliliters;
    public Beverage(String name, double price,double milliliters) {
        super(name, price);
        this.milliliters=milliliters;
    }

    public double getMilliliters() {
        return this.milliliters;
    }
}
