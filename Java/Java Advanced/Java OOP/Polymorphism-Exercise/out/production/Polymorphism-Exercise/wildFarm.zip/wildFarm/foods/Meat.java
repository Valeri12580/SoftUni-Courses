package wildFarm.foods;

import wildFarm.foods.Food;

public class Meat extends Food {
    public Meat(Integer quantity) {
        super(quantity);
    }
}
