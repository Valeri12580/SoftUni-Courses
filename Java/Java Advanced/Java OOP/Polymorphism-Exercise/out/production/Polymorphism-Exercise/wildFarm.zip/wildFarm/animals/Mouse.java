package wildFarm.animals;

import wildFarm.foods.Food;
import wildFarm.foods.Vegetable;

public class Mouse extends Mammal {
    public Mouse(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

    @Override
    public void makeSound() {
        System.out.println("SQUEEEAAAK!");
    }

    @Override
    public void eatFood(Food food) {
        if(food.getClass().getSimpleName().equals("Vegetable")){
            this.setFoodEaten(food.getQuantity()+getFoodEaten());
        }else{
            System.out.println("Mice are not eating that type of food!");
        }

    }
}
