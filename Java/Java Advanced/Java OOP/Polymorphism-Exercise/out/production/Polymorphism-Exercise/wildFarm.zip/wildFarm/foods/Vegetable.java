package wildFarm.foods;

import wildFarm.foods.Food;

public class Vegetable extends Food {
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
