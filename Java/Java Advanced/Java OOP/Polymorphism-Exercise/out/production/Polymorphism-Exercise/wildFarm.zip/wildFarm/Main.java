package wildFarm;


import wildFarm.animals.*;
import wildFarm.foods.Food;
import wildFarm.foods.Meat;
import wildFarm.foods.Vegetable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        List<Animal>animals=new ArrayList<>();



        String[] input=reader.readLine().split(" ");
        while (!input[0].equals("End")){
            String[]secondLine=reader.readLine().split(" ");
            String animalType=input[0];
            Animal animal=null;

            if(animalType.equals("Cat")){
                animal=new Cat(input[1],animalType,Double.parseDouble(input[2]),input[3],input[4]);
            }else if (animalType.equals("Tiger")){
                animal=new Tiger(input[1],animalType,Double.parseDouble(input[2]),input[3]);
            }else if (animalType.equals("Mouse")){
                animal=new Mouse(input[1],animalType,Double.parseDouble(input[2]),input[3]);

            }else if ( animalType.equals("Zebra")){
                animal=new Zebra(input[1],animalType,Double.parseDouble(input[2]),input[3]);

            }

            Food food=null;

            if(secondLine[0].equals("Meat")){
                food=new Meat(Integer.parseInt(secondLine[1]));
            }else{
                food=new Vegetable(Integer.parseInt(secondLine[1]));
            }






            animal.makeSound();
            animal.eatFood(food);
            animals.add(animal);




            input=reader.readLine().split(" ");
        }
        animals.forEach(e-> System.out.println(e));




    }
}
