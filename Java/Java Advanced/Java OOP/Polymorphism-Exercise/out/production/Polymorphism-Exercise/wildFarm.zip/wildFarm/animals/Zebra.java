package wildFarm.animals;

import wildFarm.foods.Food;
import wildFarm.foods.Vegetable;

public class Zebra extends Mammal {
    public Zebra(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

    @Override
    public void makeSound() {
        System.out.println("Zs");
    }

    @Override
    public void eatFood(Food food) {
        if(food.getClass().getSimpleName().equals("Vegetable")){
            this.setFoodEaten(food.getQuantity()+getFoodEaten());
        }else{
            System.out.println("Zebras are not eating that type of food!");
        }
    }
}
